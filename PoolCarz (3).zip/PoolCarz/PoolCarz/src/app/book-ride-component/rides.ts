export class rides
{
    from!:string;
    to!:string;
    seats!:string;
}