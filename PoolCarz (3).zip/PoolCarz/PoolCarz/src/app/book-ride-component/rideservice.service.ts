import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { rides } from './rides';

@Injectable({
  providedIn: 'root'
})
export class RideserviceService {

  constructor(private http:HttpClient) {}

  getRides():Observable<rides[]>
  {
    return this.http.get<rides[]>('assets/rides.json');
  }
}
