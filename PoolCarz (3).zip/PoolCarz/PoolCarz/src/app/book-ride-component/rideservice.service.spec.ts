import { TestBed } from '@angular/core/testing';

import { RideserviceService } from './rideservice.service';

describe('RideserviceService', () => {
  let service: RideserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RideserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
