import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterDatas'
})
export class FilterDatasPipe implements PipeTransform {

  transform(value: any[], selected:string): any[] {

    if(selected == 'from')
    {
      return value.filter(e => e.from == 'Office');
    }
    else if(selected == 'to')
    {
      return value.filter(e => e.to == 'Office');
    }else if(selected == 'others')
    {
      return value.filter(e => e.from != 'Office' && e.to != 'Office');
    }else if(selected == 'all')
    {
      return value;
    }

    return value;
  }

}
