import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { rides } from './rides';
import { RideserviceService } from './rideservice.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-book-ride-component',
  templateUrl: './book-ride-component.component.html',
  styleUrls: ['./book-ride-component.component.css']
})
export class BookRideComponentComponent implements OnInit {

  selectedRow: number = -1;
  rideComponent: boolean = false;
  oneTime: boolean = true;
  rowSelected: boolean = false;
  fromData!:string;
  selectedFilter = 'all';
  styleObject = {
    backgroundColor: 'rgba(24, 24, 203, 0.699)',
  };

  currentArrs!: rides[];
  travellArrs!: rides[];

  ngOnInit(): void {
    this.fetchRides()
  }

  constructor(private rs: RideserviceService, private router: Router) { }
  fetchRides() {
    this.rs.getRides().subscribe({
      next: rideData => {
        this.travellArrs = rideData;
      }
    })
  }

  showAllRides() {
    // console.log(this.travellArrs);

    if(this.oneTime)
    {
      this.oneTime = false; 
      this.rideComponent = !this.rideComponent;
    }
    this.currentArrs = this.travellArrs;
    // console.log(this.currentArrs);
    
  }

  offerRide() {
    console.log("transform");

    this.router.navigateByUrl('/offer-ride')
  }

  onRowClick(rowNumber: number)
  {
    this.selectedRow = rowNumber;
    this.rowSelected = true;
    this.fromData = this.currentArrs[this.selectedRow].from;
  }

  ids!:number;
  regId(courseName: number) {
    this.ids = courseName;
  }
}



// travellArrs: travel[] =[
//   new travel("Vanrose hunction","Office",3),
//   new travel("PTP","Office",2),
//   new travel("Office","East-Fort",7),
//   new travel("Office","Central Mail",5),
// ]
// class travel
// {
//   start!:string;
//   end!:string;
//   seat!:number;
//   constructor(start:string,end:string,seat:number)
//   {
//     this.start = start;
//     this.end = end;
//     this.seat = seat;
//   }
// }
