import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginserviceService } from './loginservice.service';
import { users } from './users';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit{

  registrationForm!: FormGroup;
  constructor(private fb: FormBuilder,private ls:LoginserviceService,private router: Router){}

  userName!:string;
  password!:string;
  users!:users[];

  ngOnInit(){
    this.registrationForm = this.fb.group({
      userName: ['',Validators.required],
      password:['',Validators.required]
    });
    this.fetchRides();
  }

  fetchRides()
  {
    this.ls.getUsers().subscribe({
      next: user =>{
        this.users = user
      }
    });
  }
  check:boolean = false;
  isUserValid!: boolean; 
  login()
  {
    const username = this.registrationForm.get('userName')?.value
    const password = this.registrationForm.get('password')?.value;
    
    
    this.isUserValid = this.users.some(user =>
      user.username === username && user.password === password
    );
    this.check = true;

    if(this.isUserValid)
    {
      this.router.navigateByUrl('/book-ride')
    }
  }

}
