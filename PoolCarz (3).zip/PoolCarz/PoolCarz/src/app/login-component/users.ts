export class users{
    username!:String;
    password!:string;
}