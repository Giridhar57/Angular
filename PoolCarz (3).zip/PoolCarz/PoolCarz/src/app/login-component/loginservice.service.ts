import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { users } from './users';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private http: HttpClient) { }

  getUsers() : Observable<users[]>
  {
    return this.http.get<users[]>('assets/users.json');
  }
}
