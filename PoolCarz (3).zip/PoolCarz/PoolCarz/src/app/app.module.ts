import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { BookRideComponentComponent } from './book-ride-component/book-ride-component.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterDatasPipe } from './book-ride-component/filter-datas.pipe';
import { OfferRideComponent } from './offer-ride/offer-ride.component';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { RideDetailsComponent } from './ride-details/ride-details.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponentComponent,
    BookRideComponentComponent,
    FilterDatasPipe,
    OfferRideComponent,
    RideDetailsComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
