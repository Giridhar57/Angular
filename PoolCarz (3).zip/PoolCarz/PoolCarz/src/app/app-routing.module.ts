import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponentComponent } from './login-component/login-component.component';
import { BookRideComponentComponent } from './book-ride-component/book-ride-component.component';
import { OfferRideComponent } from './offer-ride/offer-ride.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes:Routes = [
  {path:'login',component:LoginComponentComponent},
  {path:'book-ride',component:BookRideComponentComponent},
  {path:'offer-ride',component:OfferRideComponent},
  {path:'welcome',component:WelcomeComponent},
  {path:'',redirectTo:"/welcome",pathMatch:"full"},
  {path:"**",component:WelcomeComponent}
]
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
