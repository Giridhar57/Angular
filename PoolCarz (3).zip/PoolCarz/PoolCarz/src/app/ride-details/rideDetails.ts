export class rideDetails
{
    userId!:string;
    userName!:string;
    car!:   string;
    seats!:number;
    pickUp!:string;
    destination!:string;
}

