import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { rideDetails } from './rideDetails';

@Injectable({
  providedIn: 'root'
})
export class RideDetailsServiceService {

  constructor(private http: HttpClient) { }

  fetchData():Observable<rideDetails[]>
  {
    return this.http.get<rideDetails[]>('assets/rideDetails.json').pipe(
      // tap((data:any)=> console.log(data))
    )
  }
}
