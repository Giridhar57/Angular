import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { RideDetailsServiceService } from './ride-details-service.service';
import { Observable, of, switchMap, tap } from 'rxjs';
import { rideDetails } from './rideDetails';

@Component({
  selector: 'app-ride-details',
  templateUrl: './ride-details.component.html',
  styleUrls: ['./ride-details.component.css']
})
export class RideDetailsComponent implements OnInit {

  constructor(private rds: RideDetailsServiceService) { }

  dataArrs!: rideDetails[];
  length!: number;
  fromC!:string;

  ngOnInit() {
    this.fetchData()
  }

  fetchData() {
    this.rds.fetchData().subscribe({
      next: data => {
        this.dataArrs = data;
        this.length = this.dataArrs.length
        this.filterData()
      }
    })
  }

  currentArrs: rideDetails[] = [];
  @Input() set fromLocation(from: string) {
    this.fromC = from
  }

  filterData()
  { 
    console.log(this.length);
    
    for (var i = 0; i < this.length; i++) {
      // console.log(this.dataArrs[i].pickUp);
      if (this.dataArrs[i].pickUp == this.fromC) {
        console.log(this.dataArrs[i].pickUp);
        this.currentArrs.push(this.dataArrs[i]);
      }
    }
  }

  changeBtn:boolean = true;

  @Output() registerEvent = new EventEmitter<number>();
  ids:number = 100;
  sendid() {
    this.changeBtn = false;
    this.registerEvent.emit(this.ids);
  }

}
