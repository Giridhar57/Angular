import { TestBed } from '@angular/core/testing';

import { RideDetailsServiceService } from './ride-details-service.service';

describe('RideDetailsServiceService', () => {
  let service: RideDetailsServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RideDetailsServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
