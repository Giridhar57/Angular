import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-offer-ride',
  templateUrl: './offer-ride.component.html',
  styleUrls: ['./offer-ride.component.css']
})
export class OfferRideComponent implements OnInit{

  userName!:string;
  start!:string;
  destination!:string;
  car!:string;
  seat!:number;
  registerForm!: FormGroup;
  check:boolean = false;

  constructor(private fb: FormBuilder){}

  ngOnInit(){
    this.registerForm = this.fb.group({
      userName: ['',Validators.required],
      start: ['',Validators.required],
      destination: ['',Validators.required],
      car: ['',Validators.required],
      seat: ['',[Validators.required,Validators.min(1),Validators.max(8)]],
    })
  }

  dataAdded()
  {
    this.check = true;
    this.registerForm.patchValue({
      userName: "",
      start: "",
      destination: "",
      car: "",
      seat: ""
    });
  }
}
